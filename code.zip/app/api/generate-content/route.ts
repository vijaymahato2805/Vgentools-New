import { createClient } from "@/lib/supabase/server"
import { generateWithGemini } from "@/lib/gemini"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { contentType, topic, context } = await request.json()

    const prompt = `Generate ${contentType} content about: ${topic}
Context: ${context}

Create high-quality, original content that is engaging and relevant.`

    const content = await generateWithGemini(prompt)

    // Save to database
    const { error } = await supabase.from("ai_outputs").insert({
      user_id: user.id,
      type: contentType,
      input_data: { topic, context },
      output_text: content,
    })

    if (error) throw error

    return NextResponse.json({ content })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Failed to generate content" }, { status: 500 })
  }
}
