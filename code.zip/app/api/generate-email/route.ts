import { createClient } from "@/lib/supabase/server"
import { generateWithGemini } from "@/lib/gemini"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { recipient, purpose, details } = await request.json()

    const prompt = `Generate a professional email with the following details:

Recipient: ${recipient}
Purpose: ${purpose}
Additional Details: ${details}

Write a concise, professional email that achieves the stated purpose.`

    const emailContent = await generateWithGemini(prompt)

    // Save to database
    const { error } = await supabase.from("ai_outputs").insert({
      user_id: user.id,
      type: "email",
      input_data: { recipient, purpose, details },
      output_text: emailContent,
    })

    if (error) throw error

    return NextResponse.json({ email: emailContent })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Failed to generate email" }, { status: 500 })
  }
}
