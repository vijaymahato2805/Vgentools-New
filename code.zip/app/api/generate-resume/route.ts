import { createClient } from "@/lib/supabase/server"
import { generateWithGemini } from "@/lib/gemini"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { jobDescription, experience, skills } = await request.json()

    const prompt = `Generate a professional resume based on the following information:
    
Job Description: ${jobDescription}
Experience: ${experience}
Skills: ${skills}

Create a well-formatted resume that matches the job description and highlights relevant experience and skills.`

    const resumeContent = await generateWithGemini(prompt)

    // Save to database
    const { error } = await supabase.from("ai_outputs").insert({
      user_id: user.id,
      type: "resume",
      input_data: { jobDescription, experience, skills },
      output_text: resumeContent,
    })

    if (error) throw error

    return NextResponse.json({ resume: resumeContent })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Failed to generate resume" }, { status: 500 })
  }
}
