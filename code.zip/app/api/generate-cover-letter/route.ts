import { createClient } from "@/lib/supabase/server"
import { generateWithGemini } from "@/lib/gemini"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { companyName, jobTitle, experience, skills } = await request.json()

    const prompt = `Generate a professional cover letter for the following position:

Company: ${companyName}
Job Title: ${jobTitle}
Relevant Experience: ${experience}
Key Skills: ${skills}

Create a compelling cover letter that demonstrates enthusiasm for the role and highlights how the candidate's experience aligns with the job requirements.`

    const letterContent = await generateWithGemini(prompt)

    // Save to database
    const { error } = await supabase.from("ai_outputs").insert({
      user_id: user.id,
      type: "cover_letter",
      input_data: { companyName, jobTitle, experience, skills },
      output_text: letterContent,
    })

    if (error) throw error

    return NextResponse.json({ coverLetter: letterContent })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Failed to generate cover letter" }, { status: 500 })
  }
}
