"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Copy } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export default function EmailPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [recipient, setRecipient] = useState("")
  const [purpose, setPurpose] = useState("")
  const [details, setDetails] = useState("")
  const [email, setEmail] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!recipient || !purpose) {
      setError("Please fill in recipient and purpose")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/generate-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipient, purpose, details }),
      })

      if (!response.ok) throw new Error("Failed to generate email")
      const data = await response.json()
      setEmail(data.email)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-4">
      <div className="max-w-6xl mx-auto">
        <Link href="/dashboard">
          <Button variant="outline" className="mb-6 border-slate-600 text-slate-200 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <Card className="bg-slate-800 border-slate-700 h-fit lg:sticky lg:top-20">
            <CardHeader>
              <CardTitle className="text-white">Email Composer</CardTitle>
              <CardDescription className="text-slate-400">Write professional emails instantly</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="recipient" className="text-white mb-2 block">
                  Recipient / Recipient Type
                </Label>
                <Input
                  id="recipient"
                  placeholder="e.g., Hiring Manager at Google"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="purpose" className="text-white mb-2 block">
                  Email Purpose
                </Label>
                <Input
                  id="purpose"
                  placeholder="e.g., Follow up on job application"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="details" className="text-white mb-2 block">
                  Additional Details (Optional)
                </Label>
                <Textarea
                  id="details"
                  placeholder="Any additional context..."
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white h-24"
                />
              </div>

              {error && <p className="text-sm text-red-400">{error}</p>}

              <Button onClick={handleGenerate} disabled={isLoading} className="w-full bg-green-600 hover:bg-green-700">
                {isLoading ? "Composing..." : "Compose Email"}
              </Button>
            </CardContent>
          </Card>

          {/* Output Section */}
          {email && (
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-white">Generated Email</CardTitle>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 bg-transparent"
                  onClick={() => {
                    navigator.clipboard.writeText(email)
                  }}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-700 p-4 rounded-lg text-slate-100 text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                  {email}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
