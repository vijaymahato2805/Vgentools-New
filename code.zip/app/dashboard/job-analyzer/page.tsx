"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useState } from "react"
import Link from "next/link"

export default function JobAnalyzerPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [jobDescription, setJobDescription] = useState("")
  const [result, setResult] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleAnalyze = async () => {
    if (!jobDescription) {
      setError("Please paste a job description")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/generate-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentType: "job_analysis",
          topic: "Job Description Analysis",
          context: jobDescription,
        }),
      })

      if (!response.ok) throw new Error("Failed to analyze job")
      const data = await response.json()
      setResult(data.content)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-4">
      <div className="max-w-6xl mx-auto">
        <Link href="/dashboard">
          <Button variant="outline" className="mb-6 border-slate-600 text-slate-200 bg-transparent">
            ← Back to Dashboard
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="bg-slate-800 border-slate-700 h-fit lg:sticky lg:top-20">
            <CardHeader>
              <CardTitle className="text-white">Job Search Analyzer</CardTitle>
              <CardDescription className="text-slate-400">Analyze job descriptions and get insights</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="job" className="text-white mb-2 block">
                  Job Description
                </Label>
                <Textarea
                  id="job"
                  placeholder="Paste the full job description here..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white h-48"
                />
              </div>

              {error && <p className="text-sm text-red-400">{error}</p>}

              <Button onClick={handleAnalyze} disabled={isLoading} className="w-full bg-pink-600 hover:bg-pink-700">
                {isLoading ? "Analyzing..." : "Analyze Job"}
              </Button>
            </CardContent>
          </Card>

          {result && (
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-white">Analysis</CardTitle>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 bg-transparent"
                  onClick={() => {
                    navigator.clipboard.writeText(result)
                  }}
                >
                  📋
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-700 p-4 rounded-lg text-slate-100 text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                  {result}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
