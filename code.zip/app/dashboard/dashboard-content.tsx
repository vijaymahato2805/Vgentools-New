"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"
import { useState } from "react"

interface DashboardContentProps {
  user: { email: string }
}

export function DashboardContent({ user }: DashboardContentProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleLogout = async () => {
    setIsLoading(true)
    const supabase = createBrowserClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  const tools = [
    {
      title: "Resume Generator",
      description: "Create tailored resumes for any job",
      emoji: "📄",
      href: "/dashboard/resume",
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "Cover Letter Writer",
      description: "Generate compelling cover letters",
      emoji: "✉️",
      href: "/dashboard/cover-letter",
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Email Composer",
      description: "Write professional emails instantly",
      emoji: "💬",
      href: "/dashboard/email",
      color: "from-green-500 to-green-600",
    },
    {
      title: "LinkedIn Optimizer",
      description: "Optimize your LinkedIn profile",
      emoji: "💼",
      href: "/dashboard/linkedin",
      color: "from-indigo-500 to-indigo-600",
    },
    {
      title: "Interview Prep",
      description: "Get AI-powered interview questions",
      emoji: "✨",
      href: "/dashboard/interview",
      color: "from-orange-500 to-orange-600",
    },
    {
      title: "Job Search Analyzer",
      description: "Analyze job descriptions",
      emoji: "📈",
      href: "/dashboard/job-analyzer",
      color: "from-pink-500 to-pink-600",
    },
    {
      title: "Content Ideas",
      description: "Generate content and blog ideas",
      emoji: "💡",
      href: "/dashboard/content",
      color: "from-yellow-500 to-yellow-600",
    },
    {
      title: "Professional Bio",
      description: "Create professional bios",
      emoji: "📖",
      href: "/dashboard/bio",
      color: "from-cyan-500 to-cyan-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 text-blue-400">⚡</span>
            <h1 className="text-xl font-bold text-white">VGenTools</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-300">{user.email}</span>
            <Button
              onClick={handleLogout}
              disabled={isLoading}
              variant="outline"
              className="border-slate-600 text-slate-200 hover:bg-slate-800 bg-transparent"
            >
              🚪 {isLoading ? "Logging out..." : "Logout"}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Welcome back!</h2>
          <p className="text-slate-400">Choose a tool to get started</p>
        </div>

        {/* Tools Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tools.map((tool) => (
            <Link key={tool.href} href={tool.href}>
              <Card className="bg-slate-800 border-slate-700 hover:border-slate-600 cursor-pointer transition-all hover:shadow-lg h-full">
                <CardHeader>
                  <div
                    className={`bg-gradient-to-br ${tool.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 text-xl`}
                  >
                    {tool.emoji}
                  </div>
                  <CardTitle className="text-white">{tool.title}</CardTitle>
                  <CardDescription className="text-slate-400">{tool.description}</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
