"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Copy } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export default function BioPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [name, setName] = useState("")
  const [role, setRole] = useState("")
  const [achievements, setAchievements] = useState("")
  const [result, setResult] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!name || !role) {
      setError("Please enter your name and role")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/generate-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentType: "professional_bio",
          topic: `${name} - ${role}`,
          context: achievements || "Successful professional",
        }),
      })

      if (!response.ok) throw new Error("Failed to generate bio")
      const data = await response.json()
      setResult(data.content)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-4">
      <div className="max-w-6xl mx-auto">
        <Link href="/dashboard">
          <Button variant="outline" className="mb-6 border-slate-600 text-slate-200 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="bg-slate-800 border-slate-700 h-fit lg:sticky lg:top-20">
            <CardHeader>
              <CardTitle className="text-white">Professional Bio Generator</CardTitle>
              <CardDescription className="text-slate-400">Create compelling professional bios</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-white mb-2 block">
                  Your Name
                </Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="role" className="text-white mb-2 block">
                  Role / Title
                </Label>
                <Input
                  id="role"
                  placeholder="e.g., Product Manager, Designer"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="achievements" className="text-white mb-2 block">
                  Key Achievements (Optional)
                </Label>
                <Textarea
                  id="achievements"
                  placeholder="Describe your key achievements..."
                  value={achievements}
                  onChange={(e) => setAchievements(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white h-24"
                />
              </div>

              {error && <p className="text-sm text-red-400">{error}</p>}

              <Button onClick={handleGenerate} disabled={isLoading} className="w-full bg-cyan-600 hover:bg-cyan-700">
                {isLoading ? "Generating..." : "Generate Bio"}
              </Button>
            </CardContent>
          </Card>

          {result && (
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-white">Generated Bio</CardTitle>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 bg-transparent"
                  onClick={() => {
                    navigator.clipboard.writeText(result)
                  }}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-700 p-4 rounded-lg text-slate-100 text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                  {result}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
