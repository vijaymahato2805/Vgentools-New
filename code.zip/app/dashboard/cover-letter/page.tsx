"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Copy } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export default function CoverLetterPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [companyName, setCompanyName] = useState("")
  const [jobTitle, setJobTitle] = useState("")
  const [experience, setExperience] = useState("")
  const [skills, setSkills] = useState("")
  const [letter, setLetter] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!companyName || !jobTitle || !experience || !skills) {
      setError("Please fill in all fields")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/generate-cover-letter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName, jobTitle, experience, skills }),
      })

      if (!response.ok) throw new Error("Failed to generate cover letter")
      const data = await response.json()
      setLetter(data.coverLetter)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-4">
      <div className="max-w-6xl mx-auto">
        <Link href="/dashboard">
          <Button variant="outline" className="mb-6 border-slate-600 text-slate-200 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <Card className="bg-slate-800 border-slate-700 h-fit lg:sticky lg:top-20">
            <CardHeader>
              <CardTitle className="text-white">Generate Cover Letter</CardTitle>
              <CardDescription className="text-slate-400">
                Create a compelling cover letter for your application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="company" className="text-white mb-2 block">
                  Company Name
                </Label>
                <Input
                  id="company"
                  placeholder="e.g., Acme Corp"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="position" className="text-white mb-2 block">
                  Job Title
                </Label>
                <Input
                  id="position"
                  placeholder="e.g., Senior Software Engineer"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="exp" className="text-white mb-2 block">
                  Your Experience
                </Label>
                <Textarea
                  id="exp"
                  placeholder="Describe your relevant experience..."
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white h-20"
                />
              </div>

              <div>
                <Label htmlFor="skills" className="text-white mb-2 block">
                  Key Skills
                </Label>
                <Textarea
                  id="skills"
                  placeholder="List key skills..."
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white h-20"
                />
              </div>

              {error && <p className="text-sm text-red-400">{error}</p>}

              <Button
                onClick={handleGenerate}
                disabled={isLoading}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {isLoading ? "Generating..." : "Generate Cover Letter"}
              </Button>
            </CardContent>
          </Card>

          {/* Output Section */}
          {letter && (
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-white">Generated Letter</CardTitle>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 bg-transparent"
                  onClick={() => {
                    navigator.clipboard.writeText(letter)
                  }}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-700 p-4 rounded-lg text-slate-100 text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                  {letter}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
