"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
              ⚡
            </div>
            <h1 className="text-xl font-bold text-white">VGenTools</h1>
          </div>
          <div className="flex gap-2">
            <Link href="/auth/login">
              <Button variant="outline" className="border-slate-600 text-slate-200 hover:bg-slate-800 bg-transparent">
                Login
              </Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button className="bg-blue-600 hover:bg-blue-700">Sign Up</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-5xl font-bold text-white mb-6">VGenTools: 10 AI-Powered Tools for Your Career</h2>
          <p className="text-xl text-slate-300 mb-8">
            Generate resumes, cover letters, emails, and more with the power of AI. Powered by Google Gemini.
          </p>
          <Link href="/auth/sign-up">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">Get Started Free →</Button>
          </Link>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Resume Generator</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Create professional resumes tailored to any job description.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Cover Letter Writer</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Generate compelling cover letters in seconds.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Email Composer</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Write professional emails for any occasion.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">LinkedIn Optimizer</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Optimize your LinkedIn profile for maximum impact.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Interview Prep</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Get AI-powered interview questions and answers.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Job Search Analyzer</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">Analyze job descriptions and get matching insights.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
