import type { NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  // Middleware stub - authentication handled client-side
  return null
}
