export function getSupabaseClient() {
  return {
    auth: {
      signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
        // Mock authentication for demo purposes
        if (!email || !password) {
          return { data: null, error: new Error("Email and password required") }
        }
        // Store auth state in localStorage
        localStorage.setItem("vgentools_user", JSON.stringify({ email, loggedIn: true }))
        return {
          data: { session: { user: { email } } },
          error: null,
        }
      },
      signUp: async ({ email, password, options }: any) => {
        if (!email || !password) {
          return { data: null, error: new Error("Email and password required") }
        }
        localStorage.setItem("vgentools_user", JSON.stringify({ email, loggedIn: true }))
        return { data: { user: { email } }, error: null }
      },
      getUser: async () => {
        const user = localStorage.getItem("vgentools_user")
        if (user) {
          const userData = JSON.parse(user)
          return { data: { user: userData }, error: null }
        }
        return { data: { user: null }, error: null }
      },
      signOut: async () => {
        localStorage.removeItem("vgentools_user")
        return { error: null }
      },
    },
    from: (tableName: string) => {
      return {
        insert: async (data: any) => {
          // Mock database insert - just return success
          console.log(`[Mock] Inserting into ${tableName}:`, data)
          return { error: null }
        },
      }
    },
  }
}

export function createBrowserClient() {
  return getSupabaseClient()
}

export function createClient() {
  return getSupabaseClient()
}
