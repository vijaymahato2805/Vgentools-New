import { getSupabaseClient } from "./client"

export async function createClient() {
  return getSupabaseClient()
}
