import { generateText } from "ai"

export async function generateWithGemini(prompt: string): Promise<string> {
  try {
    const { text } = await generateText({
      model: "google/gemini-2.0-flash",
      prompt: prompt,
    })
    return text
  } catch (error) {
    console.error("Error generating content:", error)
    throw new Error("Failed to generate content")
  }
}

export async function streamWithGemini(prompt: string) {
  try {
    // For streaming, return the readable stream
    const result = await generateText({
      model: "google/gemini-2.0-flash",
      prompt: prompt,
    })
    return result
  } catch (error) {
    console.error("Error streaming content:", error)
    throw new Error("Failed to stream content")
  }
}
