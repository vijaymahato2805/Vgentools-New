// The dashboard will handle authentication client-side instead
export function middleware() {
  // Middleware disabled - using client-side auth instead
}

export const config = {
  matcher: [],
}
