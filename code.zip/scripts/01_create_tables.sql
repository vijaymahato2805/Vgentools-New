-- Create ai_outputs table for storing generated content
CREATE TABLE IF NOT EXISTS ai_outputs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- resume, cover_letter, email, content, etc
  input_data JSONB,
  output_text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE ai_outputs ENABLE ROW LEVEL SECURITY;

-- Create RLS policy for users to access only their outputs
CREATE POLICY "Users can view their own ai_outputs"
  ON ai_outputs
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create ai_outputs"
  ON ai_outputs
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their ai_outputs"
  ON ai_outputs
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their ai_outputs"
  ON ai_outputs
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_ai_outputs_user_id ON ai_outputs(user_id);
CREATE INDEX idx_ai_outputs_type ON ai_outputs(type);
CREATE INDEX idx_ai_outputs_created_at ON ai_outputs(created_at DESC);
